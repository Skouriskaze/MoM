package com.example.mom.mom.View;

/**
 * Created by jesse on 3/7/16.
 */
public interface LogoutListener {

    void onLogout();
}
