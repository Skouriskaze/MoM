package com.example.mom.mom;

/**
 * Created by Jesse on 2/18/2016.
 */
public class Movie {
    String m_szTitle;
    String m_szPosterURL;
    String m_szYear;

    public Movie(String szTitle, String szPosterURL, String szYear) {
        m_szTitle = szTitle;
        m_szPosterURL = szPosterURL;
        m_szYear = szYear;
    }

    public String getTitle() {
        return m_szTitle;
    }

    public String getPosterURL() {
        return m_szPosterURL;
    }

    public String getYear() {
        return m_szYear;
    }
}
