package com.example.mom.mom.View;

import com.example.mom.mom.Model.Major;

/**
 * Created by jesse on 3/7/16.
 */
public interface ProfileView {
    void setName(String name);

    void setBio(String bio);

    void setMajor(Major major);
}
