package com.example.mom.mom;

/**
 * Created by Jesse on 2/3/2016.
 */
public interface AuthenticationInterface {

    /**
     * Add a user to the authentication
     * @param szUsername username
     * @param szPassword password
     */
    User add(String szUsername, String szPassword);

    /**
     * Removes user
     * @param szUsername username
     * @return User that was removed
     */
    User remove(String szUsername);
}
