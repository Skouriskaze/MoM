package com.example.mom.mom.View;

import android.content.Context;

/**
 * Created by jesse on 3/6/16.
 */
public interface MovieListView {
    
    String getSearch();

    Context getContext();

    int getPosition();
}
