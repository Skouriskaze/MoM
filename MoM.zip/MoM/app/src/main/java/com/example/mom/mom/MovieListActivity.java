package com.example.mom.mom;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Movie List
 */
public class MovieListActivity extends AppCompatActivity {

    public static ArrayAdapter<Movie> m_aAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_list);

        //Set appbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Set List View
        ListView lvMovies = (ListView) findViewById(R.id.lvMovies);

        //Search movies
        SearchController.getSearchResults(this);

        m_aAdapter = new MovieAdapter(this, SearchController.m_aMovies);

        lvMovies.setAdapter(m_aAdapter);
    }

    /**
     * Testing change in movie thing
     * @param view
     */
    public void onEditClick(View view) {
        SearchController.m_aMovies.add(new Movie("Title", "N/A", "1996"));
        m_aAdapter.notifyDataSetChanged();
    }

    /**
     * Adapter for a list
     */
    public class MovieAdapter extends ArrayAdapter<Movie> {
        public MovieAdapter(Context oContext, List<Movie> aMovies) {
            super(oContext, 0, aMovies);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Get the data item for this position
            Movie oMovie = getItem(position);
            // Check if an existing view is being reused, otherwise inflate the view
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_movie, parent, false);
            }
            // Lookup view for data population
            TextView tvName = (TextView) convertView.findViewById(R.id.txtTitle);
            ImageView imgPoster = (ImageView) convertView.findViewById(R.id.imgPoster);

            // Populate the data into the template view using the data object
            tvName.setText(oMovie.getTitle());
            if (!oMovie.getPosterURL().equalsIgnoreCase("N/A") && imgPoster.getTag().equals("unset")) {
                new ImageURLProcessor(imgPoster).execute(oMovie.getPosterURL());
                imgPoster.setTag("set");
            }


            // Return the completed view to render on screen
            return convertView;
        }

        /**
         * Processes image URL and puts it in the view
         */
        public class ImageURLProcessor extends AsyncTask<String, Void, Bitmap> {
            ImageView m_imgPoster;
            public ImageURLProcessor(ImageView imgPoster) {
                m_imgPoster = imgPoster;
            }

            protected Bitmap doInBackground(String... urls) {
                String szURLDisplay = urls[0];
                Bitmap imgPoster = null;
                try {
                    InputStream in = new java.net.URL(szURLDisplay).openStream();
                    imgPoster = BitmapFactory.decodeStream(in);
                    in.close();
                } catch (Exception e) {
                    Log.e("Error", e.getMessage());
                    e.printStackTrace();
                }

                return imgPoster;
            }

            protected void onPostExecute(Bitmap result) {
                m_imgPoster.setImageBitmap(result);
            }
        }
    }
}
