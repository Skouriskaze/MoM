package com.example.mom.mom;

/**
 * Created by Jesse on 2/12/2016.
 */
public class Session {
    public static User oUser;
    public static String szSearch;

}
