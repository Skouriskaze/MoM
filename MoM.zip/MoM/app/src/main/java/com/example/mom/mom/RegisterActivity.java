package com.example.mom.mom;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    String m_szUsername; //Username passed in from login

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_register);
        findViewById(R.id.txtUsername).requestFocus();

        //Set appbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent intent = getIntent();
        m_szUsername = intent.getStringExtra(LoginActivity.EXTRA_USERNAME);

        if (null != m_szUsername && !m_szUsername.equals("")) {
            EditText oUsername = (EditText) findViewById(R.id.txtUsername);
            oUsername.setText(m_szUsername);
            findViewById(R.id.txtPassword).requestFocus();
        }
    }

    /**
     * Tries to register  an account.
     * @param view
     */
    public void onRegisterPress(View view) {
        //Close keyboard
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);

        EditText oUsername = (EditText) findViewById(R.id.txtUsername);
        EditText oPassword = (EditText) findViewById(R.id.txtPassword);
        EditText oPasswordConfirm = (EditText) findViewById(R.id.txtPasswordConfirm);

        String szUsername = oUsername.getText().toString().trim();
        String szPassword = oPassword.getText().toString().trim();
        String szPasswordConfirm = oPasswordConfirm.getText().toString().trim();

        if (szPassword.equals(szPasswordConfirm)) {
            //Password match.
            AuthenticationInterface auth = new LoginManager();
            if (null != auth.add(szUsername, szPassword))
            {
                Toast.makeText(RegisterActivity.this, oUsername.getText().toString().trim() + " is successfully added!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(RegisterActivity.this, oUsername.getText().toString().trim() + " has already been registered", Toast.LENGTH_SHORT).show();
            }


            returnToLogin();
        } else {
            //Passwords don't match.
            Toast.makeText(RegisterActivity.this, "Passwords don't match!", Toast.LENGTH_SHORT).show();

            //Clear passwords
            oPassword.setText("");
            oPasswordConfirm.setText("");

            oPassword.requestFocus();
        }

    }

    /**
     * Goes to login screen.
     * @param view
     */
    public void onLoginPress(View view) {
        returnToLogin();
    }

    /**
     * Layout press. Closes keyboard.
     * @param view
     */
    public void onLayoutPress(View view) {
        //Close keyboard
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    /**
     * Returns to login screen.
     */
    private void returnToLogin() {
        EditText username = (EditText) findViewById(R.id.txtUsername);

        Intent oIntent = new Intent(this, LoginActivity.class);
        oIntent.putExtra(LoginActivity.EXTRA_USERNAME, username.getText().toString());
        oIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(oIntent);
    }
}
