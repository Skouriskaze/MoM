package com.example.mom.mom.View;

/**
 * Created by jesse on 2/29/16.
 */
public interface ClickListener {
    void onClick();
}
