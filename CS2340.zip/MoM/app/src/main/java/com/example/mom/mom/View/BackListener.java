package com.example.mom.mom.View;

/**
 * Created by Jesse on 3/8/2016.
 */
public interface BackListener {

    void onBackPressed();
}
