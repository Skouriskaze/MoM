package com.example.mom.mom;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

public class EditProfileActivity extends AppCompatActivity {

    User m_oCurrentUser; //User that has logged in

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        //Set appbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Get user
        //Intent oIntent = getIntent();
        //LoginManager oLogin = new LoginManager();
        //oCurrentUser = oLogin.getUsers().get(oIntent.getStringExtra(LoginActivity.EXTRA_USERNAME));
        m_oCurrentUser = Session.oUser;

        //Get fields
        TextView oUsername = (TextView) findViewById(R.id.txtUsername);
        EditText oName = (EditText) findViewById(R.id.etName);
        EditText oBio = (EditText) findViewById(R.id.etBio);
        EditText oMajor = (EditText) findViewById(R.id.etMajor);

        //Sets fields
        oName.setText(m_oCurrentUser.getName());
        oUsername.setText(m_oCurrentUser.getUsername());
        oBio.setText(m_oCurrentUser.getBio());
        oMajor.setText(m_oCurrentUser.getMajor());
    }

    /**
     * Sets profile attributes
     * @param view View that called this method
     */
    public void onSetPress(View view) {
        EditText oName = (EditText) findViewById(R.id.etName);
        EditText oBio = (EditText) findViewById(R.id.etBio);
        EditText oMajor = (EditText) findViewById(R.id.etMajor);

        String szName = oName.getText().toString();
        String szBio = oBio.getText().toString();
        String szMajor = oMajor.getText().toString();

        m_oCurrentUser.setName(szName);
        m_oCurrentUser.setMajor(szMajor);
        m_oCurrentUser.setBio(szBio);

        returnHome();
    }

    /**
     * Cancels edit
     * @param view view that called this method
     */
    public void onCancelPress(View view) {
        confirmExit();
    }

    /**
     * Returns back to home activity
     */
    private void returnHome() {
        //Return to home
        Intent oIntent = new Intent(this, ProfileActivity.class);
        oIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        //oIntent.putExtra(LoginActivity.EXTRA_USERNAME, m_oCurrentUser.getUsername());

        startActivity(oIntent);

        finish();
    }

    /**
     * On layout click. Clears soft keyboard. //Push
     * @param view view that is passed in
     */
    public void layoutClear(View view) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    @Override
    public void onBackPressed() {
        confirmExit();
    }

    private void confirmExit() {
        //TODO: Fix this confirmation
        //Check if changes have been made

        //Popup confirmation
        new AlertDialog.Builder(this)
                .setTitle("Exit")
                .setMessage("Do you want really want to exit? Changes will be lost.")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        returnHome();
                    }
                })
                .setNegativeButton("No", null)
                .show();
    }
}
