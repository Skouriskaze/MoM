package com.example.mom.mom;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class ProfileActivity extends AppCompatActivity {

    User m_oCurrentUser; //User that has logged in

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        //Set appbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Set current user
        //Intent oIntent = getIntent();
        //LoginManager oLogin = new LoginManager();
        //m_oCurrentUser = oLogin.getUsers().get(oIntent.getStringExtra(LoginActivity.EXTRA_USERNAME));
        m_oCurrentUser = Session.oUser;

        //Set profile text
        TextView txtUsername = (TextView) findViewById(R.id.txtName);
        TextView txtMajor = (TextView) findViewById(R.id.txtMajor);
        TextView txtBio = (TextView) findViewById(R.id.txtBio);

        //Sets profile text
        if (null != m_oCurrentUser.getName() && !m_oCurrentUser.getName().equals("")) {
            //Nickname is enabled
            txtUsername.setText(m_oCurrentUser.getName());
        } else {
            txtUsername.setText(m_oCurrentUser.getUsername());
        }

        txtMajor.setText(m_oCurrentUser.getMajor());
        txtBio.setText(m_oCurrentUser.getBio());

        //Turns scroll on Bio on
        txtBio.setMovementMethod(new ScrollingMovementMethod());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_home, menu);
        return true;
    }


    /**
     * Logs out and returns to login screen
     * @param view view that sent request
     */
    public void onLogoutPress(View view) {
        //Popup confirmation
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Do you want really want log out?")
                .setNegativeButton("No", null)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        logout();
                    }
                })
                .show();
    }

    /**
     * Logs out and returns to login screen
     * @param item item that sent request
     */
    public void onLogoutPress(MenuItem item) {
        //Popup confirmation
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Do you really want to log out?")
                .setNegativeButton("No", null)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        logout();
                    }
                })
                .show();
    }

    /**
     * Logs out and returns to login screen
     */
    private void logout() {

        //Set session
        Session.oUser = null;

        Intent oIntent = new Intent(this, LoginActivity.class);
        oIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(oIntent);
    }

    /**
     * Goes to edit profile activity
     * @param view View that calls this method
     */
    public void onEditProfilePress(View view) {
        editProfile();
    }

    /**
     * Goes to edit profile activity
     * @param item Item that calls this method
     */
    public void onEditProfilePress(MenuItem item) {
        editProfile();
    }

    /**
     * Goes to edit profile activity
     */
    private void editProfile() {
        Intent oIntent = new Intent(this, EditProfileActivity.class);
        //oIntent.putExtra(LoginActivity.EXTRA_USERNAME, m_oCurrentUser.getUsername());

        startActivity(oIntent);
    }
}
