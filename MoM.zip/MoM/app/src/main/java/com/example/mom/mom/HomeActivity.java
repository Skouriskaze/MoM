package com.example.mom.mom;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //Set appbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }

    /**
     * Takes input and searches
     * @param view view that called method
     */
    public void onSearchClick(View view) {
        //Todo: check valid search
        EditText etSearch = (EditText) findViewById(R.id.etSearch);

        String szSearch = etSearch.getText().toString();

        Intent oIntent = new Intent(this, MovieListActivity.class);
        Session.szSearch = szSearch;

        startActivity(oIntent);
    }

    /**
     * Goes to profile view
     * @param view
     */
    public void onProfileClick(View view) {
        Intent oIntent = new Intent(this, ProfileActivity.class);
        startActivity(oIntent);
    }

}
