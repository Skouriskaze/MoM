package com.example.mom.mom;

import android.util.Log;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Jesse on 2/3/2016.
 */
public class LoginManager implements AuthenticationInterface, LoginInterface {
    private static Map<String, User> aUsers = new HashMap<>();

    @Override
    public User add(String szUsername, String szPassword) {
        szUsername = szUsername.toLowerCase();

        Log.d("tag", szUsername);
        Log.d("tag", szPassword);
        Log.d("tag", aUsers.toString());

        if (!aUsers.containsKey(szUsername)) {
            //Add to map
            User oCurr = new User(szUsername, szPassword);
            aUsers.put(szUsername, oCurr);
            return oCurr;
        } else {
            return null;
            //User has already registered!

        }
    }

    @Override
    public User remove(String szUsername) {
        szUsername = szUsername.toLowerCase();

        if (aUsers.containsKey(szUsername)) {
            //Remove user
            return aUsers.remove(szUsername);
        } else {
            //No such user
            return null;
        }
    }

    @Override
    public User login(String szUsername, String szPassword) {
        szUsername = szUsername.toLowerCase();

        if (aUsers.containsKey(szUsername) && aUsers.get(szUsername).getPassword().equals(szPassword)) {
            return aUsers.get(szUsername);
        }
        return null;
    }

    public User getUser(String szUsername) {
        szUsername = szUsername.toLowerCase();
        return aUsers.get(szUsername);
    }

    /**
     * Gets map of users
     * @return all users
     */
    /*public Map<String, User> getUsers() {
        return aUsers;
    }*/
}
